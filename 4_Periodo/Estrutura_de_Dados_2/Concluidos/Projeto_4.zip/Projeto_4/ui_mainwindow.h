/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_6;
    QLabel *label_7;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEditQuantElementos;
    QPushButton *pushButtonGerar;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QLabel *label_3;
    QTextEdit *textEditSaida;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QTextEdit *textEditResultado;
    QPushButton *pushButton;
    QWidget *layoutWidget3;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_8;
    QTextEdit *textEditSelectionSort;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_9;
    QLineEdit *lineEditValor;
    QLabel *label_4;
    QLabel *label_10;
    QWidget *layoutWidget5;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_11;
    QLineEdit *lineEditValorBi;
    QWidget *layoutWidget6;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_12;
    QTextEdit *textEditResultadoBi;
    QPushButton *pushButtonBinario;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1156, 647);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setStyleSheet(QString::fromUtf8(""));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(360, 30, 411, 41));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(100, 40, 91, 111));
        label_6->setPixmap(QPixmap(QString::fromUtf8(":/new/fotos/Fotos/5381b99b-744e-4884-991c-aff57dbb6a9a (1).jpeg")));
        label_6->setScaledContents(true);
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(970, 30, 91, 121));
        label_7->setPixmap(QPixmap(QString::fromUtf8(":/new/fotos/Fotos/puc-goias-vertical-logo-6B1DC20460-seeklogo.com.png")));
        label_7->setScaledContents(true);
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(350, 80, 431, 46));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName("label_2");

        horizontalLayout->addWidget(label_2);

        lineEditQuantElementos = new QLineEdit(layoutWidget);
        lineEditQuantElementos->setObjectName("lineEditQuantElementos");

        horizontalLayout->addWidget(lineEditQuantElementos);

        pushButtonGerar = new QPushButton(layoutWidget);
        pushButtonGerar->setObjectName("pushButtonGerar");
        QFont font;
        font.setFamilies({QString::fromUtf8("Ubuntu Condensed")});
        font.setPointSize(12);
        font.setBold(true);
        pushButtonGerar->setFont(font);

        horizontalLayout->addWidget(pushButtonGerar);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName("layoutWidget1");
        layoutWidget1->setGeometry(QRect(300, 140, 581, 100));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName("label_3");

        verticalLayout->addWidget(label_3);

        textEditSaida = new QTextEdit(layoutWidget1);
        textEditSaida->setObjectName("textEditSaida");
        textEditSaida->setReadOnly(true);

        verticalLayout->addWidget(textEditSaida);

        layoutWidget2 = new QWidget(centralwidget);
        layoutWidget2->setObjectName("layoutWidget2");
        layoutWidget2->setGeometry(QRect(510, 330, 431, 72));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget2);
        label_5->setObjectName("label_5");

        horizontalLayout_3->addWidget(label_5);

        textEditResultado = new QTextEdit(layoutWidget2);
        textEditResultado->setObjectName("textEditResultado");
        textEditResultado->setReadOnly(true);

        horizontalLayout_3->addWidget(textEditResultado);

        pushButton = new QPushButton(layoutWidget2);
        pushButton->setObjectName("pushButton");
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        pushButton->setFont(font1);

        horizontalLayout_3->addWidget(pushButton);

        layoutWidget3 = new QWidget(centralwidget);
        layoutWidget3->setObjectName("layoutWidget3");
        layoutWidget3->setGeometry(QRect(300, 210, 581, 100));
        verticalLayout_2 = new QVBoxLayout(layoutWidget3);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(layoutWidget3);
        label_8->setObjectName("label_8");

        verticalLayout_2->addWidget(label_8);

        textEditSelectionSort = new QTextEdit(layoutWidget3);
        textEditSelectionSort->setObjectName("textEditSelectionSort");
        textEditSelectionSort->setReadOnly(true);

        verticalLayout_2->addWidget(textEditSelectionSort);

        layoutWidget4 = new QWidget(centralwidget);
        layoutWidget4->setObjectName("layoutWidget4");
        layoutWidget4->setGeometry(QRect(220, 330, 281, 31));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(layoutWidget4);
        label_9->setObjectName("label_9");

        horizontalLayout_4->addWidget(label_9);

        lineEditValor = new QLineEdit(layoutWidget4);
        lineEditValor->setObjectName("lineEditValor");

        horizontalLayout_4->addWidget(lineEditValor);

        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(220, 300, 431, 31));
        label_10 = new QLabel(centralwidget);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(220, 365, 311, 21));
        layoutWidget5 = new QWidget(centralwidget);
        layoutWidget5->setObjectName("layoutWidget5");
        layoutWidget5->setGeometry(QRect(220, 390, 281, 31));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget5);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_11 = new QLabel(layoutWidget5);
        label_11->setObjectName("label_11");

        horizontalLayout_2->addWidget(label_11);

        lineEditValorBi = new QLineEdit(layoutWidget5);
        lineEditValorBi->setObjectName("lineEditValorBi");

        horizontalLayout_2->addWidget(lineEditValorBi);

        layoutWidget6 = new QWidget(centralwidget);
        layoutWidget6->setObjectName("layoutWidget6");
        layoutWidget6->setGeometry(QRect(510, 390, 431, 72));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget6);
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_12 = new QLabel(layoutWidget6);
        label_12->setObjectName("label_12");

        horizontalLayout_5->addWidget(label_12);

        textEditResultadoBi = new QTextEdit(layoutWidget6);
        textEditResultadoBi->setObjectName("textEditResultadoBi");

        horizontalLayout_5->addWidget(textEditResultadoBi);

        pushButtonBinario = new QPushButton(layoutWidget6);
        pushButtonBinario->setObjectName("pushButtonBinario");
        pushButtonBinario->setFont(font1);

        horizontalLayout_5->addWidget(pushButtonBinario);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1156, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:700; color:#000000;\">Estrutura de Dados II - Atividade 04</span></p></body></html>", nullptr));
        label_6->setText(QString());
        label_7->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700; color:#000000;\">Quantidade de<br/>Elementos</span></p></body></html>", nullptr));
        pushButtonGerar->setText(QCoreApplication::translate("MainWindow", "GERAR", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700; color:#000000;\">Dados gerados aleatoriamente incluidos no vetor</span></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700; color:#000000;\">RESULTADO</span></p></body></html>", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "BUSCAR", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">Dados do vetor ordenados</span></p></body></html>", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">VALOR</span></p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">Busca sequencial melhorada em um vetor - ORDENADO</span></p></body></html>", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">Busca bin\303\241ria em um vetor - ORDENADO</span></p></body></html>", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">VALOR</span></p></body></html>", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">RESULTADO</span></p></body></html>", nullptr));
        pushButtonBinario->setText(QCoreApplication::translate("MainWindow", "BUSCAR", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
