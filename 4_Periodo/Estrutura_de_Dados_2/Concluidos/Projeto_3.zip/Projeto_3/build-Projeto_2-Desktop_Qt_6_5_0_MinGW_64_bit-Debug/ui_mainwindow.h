/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_6;
    QLabel *label_7;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEditQuantElementos;
    QPushButton *pushButtonGerar;
    QWidget *widget1;
    QVBoxLayout *verticalLayout;
    QLabel *label_3;
    QTextEdit *textEditSaida;
    QWidget *widget2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QTextEdit *textEditResultado;
    QPushButton *pushButton;
    QWidget *widget3;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_8;
    QTextEdit *textEditSelectionSort;
    QWidget *widget4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_9;
    QLineEdit *lineEditValor;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1086, 482);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(310, 10, 411, 41));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(50, 20, 91, 111));
        label_6->setPixmap(QPixmap(QString::fromUtf8(":/new/fotos/Fotos/5381b99b-744e-4884-991c-aff57dbb6a9a (1).jpeg")));
        label_6->setScaledContents(true);
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(920, 10, 91, 121));
        label_7->setPixmap(QPixmap(QString::fromUtf8(":/new/fotos/Fotos/puc-goias-vertical-logo-6B1DC20460-seeklogo.com.png")));
        label_7->setScaledContents(true);
        widget = new QWidget(centralwidget);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(300, 60, 431, 46));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget);
        label_2->setObjectName("label_2");

        horizontalLayout->addWidget(label_2);

        lineEditQuantElementos = new QLineEdit(widget);
        lineEditQuantElementos->setObjectName("lineEditQuantElementos");

        horizontalLayout->addWidget(lineEditQuantElementos);

        pushButtonGerar = new QPushButton(widget);
        pushButtonGerar->setObjectName("pushButtonGerar");
        QFont font;
        font.setFamilies({QString::fromUtf8("Ubuntu Condensed")});
        font.setPointSize(12);
        font.setBold(true);
        pushButtonGerar->setFont(font);

        horizontalLayout->addWidget(pushButtonGerar);

        widget1 = new QWidget(centralwidget);
        widget1->setObjectName("widget1");
        widget1->setGeometry(QRect(250, 120, 581, 61));
        verticalLayout = new QVBoxLayout(widget1);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(widget1);
        label_3->setObjectName("label_3");

        verticalLayout->addWidget(label_3);

        textEditSaida = new QTextEdit(widget1);
        textEditSaida->setObjectName("textEditSaida");

        verticalLayout->addWidget(textEditSaida);

        widget2 = new QWidget(centralwidget);
        widget2->setObjectName("widget2");
        widget2->setGeometry(QRect(250, 310, 431, 41));
        horizontalLayout_3 = new QHBoxLayout(widget2);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(widget2);
        label_5->setObjectName("label_5");

        horizontalLayout_3->addWidget(label_5);

        textEditResultado = new QTextEdit(widget2);
        textEditResultado->setObjectName("textEditResultado");

        horizontalLayout_3->addWidget(textEditResultado);

        pushButton = new QPushButton(widget2);
        pushButton->setObjectName("pushButton");
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        pushButton->setFont(font1);

        horizontalLayout_3->addWidget(pushButton);

        widget3 = new QWidget(centralwidget);
        widget3->setObjectName("widget3");
        widget3->setGeometry(QRect(250, 190, 581, 61));
        verticalLayout_2 = new QVBoxLayout(widget3);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(widget3);
        label_8->setObjectName("label_8");

        verticalLayout_2->addWidget(label_8);

        textEditSelectionSort = new QTextEdit(widget3);
        textEditSelectionSort->setObjectName("textEditSelectionSort");

        verticalLayout_2->addWidget(textEditSelectionSort);

        widget4 = new QWidget(centralwidget);
        widget4->setObjectName("widget4");
        widget4->setGeometry(QRect(250, 270, 281, 31));
        horizontalLayout_4 = new QHBoxLayout(widget4);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(widget4);
        label_9->setObjectName("label_9");

        horizontalLayout_4->addWidget(label_9);

        lineEditValor = new QLineEdit(widget4);
        lineEditValor->setObjectName("lineEditValor");

        horizontalLayout_4->addWidget(lineEditValor);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1086, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:700; color:#000000;\">Estrutura de Dados II - Atividade 03</span></p></body></html>", nullptr));
        label_6->setText(QString());
        label_7->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700; color:#000000;\">Quantidade de<br/>Elementos</span></p></body></html>", nullptr));
        pushButtonGerar->setText(QCoreApplication::translate("MainWindow", "GERAR", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700; color:#000000;\">Dados gerados aleatoriamente incluidos no vetor</span></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700; color:#000000;\">RESULTADO</span></p></body></html>", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "BUSCAR", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">Dados do vetor ordenados</span></p></body></html>", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">VALOR</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
